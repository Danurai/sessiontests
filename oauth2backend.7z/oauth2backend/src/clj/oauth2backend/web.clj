(ns oauth2backend.web
   (:require [chord.http-kit :refer [with-channel]]
            ;;[clojure.java.io :as io]
            [compojure.core :refer [defroutes GET POST]]
            [compojure.route :refer [not-found resources]]
            [ring.util.response :refer [file-response resource-response]]
            ;;[ring.middleware.oauth2 :refer [wrap-oauth2]]
            [clojure.core.async :refer [>! <! chan go go-loop mult tap]]))


(defroutes app
   (GET "/" [] (resource-response "index.html" {:root "public"}))
   (resources "/"))
   
;; (def app
;;  (-> app-routes
;;      ;;wrappers))